document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    const password = document.getElementById('password').value; // Get the password input
    const correctPassword = '20242027'; // Set your password
    const messageElement = document.getElementById('message'); // Element to display messages

    if (password === correctPassword) {
        messageElement.textContent = 'Correct password! Redirecting...'; // Success message
        messageElement.style.color = 'green'; // Change message color
        setTimeout(() => {
            window.location.href = 'https://codepen.io/Jeremiah-Sadongo/pen/zYgwawV'; // Redirect to your access page
        }, 2000); // Redirect after 2 seconds
    } else {
        messageElement.textContent = 'Incorrect password!'; // Error message
        messageElement.style.color = 'red'; // Change message color
    }
});
